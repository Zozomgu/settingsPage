package za.ac.opsc.settingspagedemo;

public class Account {
}
