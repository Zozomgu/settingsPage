package za.ac.opsc.settingspagedemo;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CompoundButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

public class changeSettingsPage extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    ToggleButton toggleButton1, toggleButton2;
    TextView textViewkm, textViewmiles;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_settings_page);

        ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle("Change Settings");
        actionBar.setDisplayShowHomeEnabled(true);
        actionBar.setDisplayHomeAsUpEnabled(true);

        toggleButton1 = findViewById(R.id.toggleButton2);
        toggleButton2 = findViewById(R.id.toggleButton3);
        textViewkm= findViewById(R.id.textView3);
        textViewmiles= findViewById(R.id.textView4);


        toggleButton1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean b)
            {
                if(toggleButton1.isChecked())
                {
                    textViewkm.setText("Kilometres Button is Checked");
                }
                else
                {
                    textViewkm.setText("Kilometres Button is unchecked");
                }
            }
        });
        toggleButton2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean b) {
                if(toggleButton2.isChecked())
                {
                    textViewmiles.setText("Miles Button is Checked");
                }
                else
                {
                    textViewmiles.setText("Miles Button is unchecked");
                }
            }
        });


        Spinner spinner = findViewById(R.id.spinner_landmarkType);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.landmarkType, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        spinner.setOnItemSelectedListener(this);

    }


    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        String text = parent.getItemAtPosition(position).toString();
        Toast.makeText(parent.getContext(), text, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}